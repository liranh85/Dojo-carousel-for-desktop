var carouselWidgetObj = {};
carouselWidgetObj.temp = /*"dojo/text!/" + */document.getElementsByTagName("script")[1].attributes['src'].nodeValue;
carouselWidgetObj.path = carouselWidgetObj.temp.substring(0,carouselWidgetObj.temp.lastIndexOf("/"));
carouselWidgetObj.dojoTextAndPath = "dojo/text!/" + carouselWidgetObj.path + "/carousel_widget.html";
define(["dojo/_base/declare", "dojo/on", "dojo/dom", "dojo/dom-construct", "dojo/query", "dojo/_base/array", "dojo/dom-attr", "dijit/_WidgetBase", "dijit/_TemplatedMixin", carouselWidgetObj.dojoTextAndPath, "dojo/ready", "dojo/NodeList-traverse", "dojo/NodeList-manipulate"],
	function(declare, on, dom, domConstruct, query, array, domAttr, _WidgetBase, _TemplatedMixin, template) {	
	return declare("carouselWidget", [_WidgetBase, _TemplatedMixin], {
		images: null,
		widgetWidth: 640,
		widgetHeight: 480,
		templateString: template,
		
        postCreate: function(){
			if(dom.byId("carousel_widget_css") == null)
			{
				query("head").append('<link id="carousel_widget_css" href="' + carouselWidgetObj.path + '/carousel_widget.css" rel="stylesheet" />');
			}
			this.setup();
        },

        setup: function(images){
			var that = this;
			if(this.images == null)
			{
				this.images = ["no image"];
			}
			if(this.images.constructor == (new Array).constructor)
			{
				var ul = domConstruct.create("ul", {style: 'width: ' + this.widgetWidth + 'px; height: ' + this.widgetHeight + 'px;'}, this.carouselV6Wrapper, "last");
				var htmlOutput = '';
				array.forEach(this.images, function(data) {
					htmlOutput = '<img src="/images/' + data + '" width="' + that.widgetWidth + '" height="' + that.widgetHeight + '" alt="' + data + '" />';
					domConstruct.create("li", {innerHTML: htmlOutput}, ul);
				});
				var currentPos = 0;
				query("li", this.carouselV6Wrapper).at(0).style("width", that.widgetWidth + "px");
				query("ul", this.carouselV6Wrapper).at(0).style("display", "block");
				on(query("ul", this.carouselV6Wrapper), "click", function() {
					query("li", that.id).at(currentPos).style("width", "0px");
					if(currentPos < that.images.length-1)
					{
						currentPos++;
					}
					else
					{
						currentPos = 0;
					}
					query("li", that.id).at(currentPos).style("width", that.widgetWidth + "px");
				});
			}
        }
    });
});