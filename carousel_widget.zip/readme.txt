This carousel was created by Liran (liranh85 in GitHub) in the process of practicing Dojo at work. It was completed on 3.9.2014.
The main reason for building it was that I could not find any Dojo carousel widget for desktop, so I decided to build one myself.

What this widget does is: it uses the images in its "images" folder to build a carousel (DOM + Dojo JS events) which slides the next image into view when clicked, using Dojo + CSS transitions.

Since I'm very new to both Dojo and GitHub, and this is my very first GitHub upload, I would appreciate any comments/suggestions/complaints/etc. about the widget or GitHub-related issues.

Enjoy!